"""Reversium: local, evidence-backed software inventory."""
__version__ = "0.24.1"
